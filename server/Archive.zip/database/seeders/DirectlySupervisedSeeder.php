<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DirectlySupervisedSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
