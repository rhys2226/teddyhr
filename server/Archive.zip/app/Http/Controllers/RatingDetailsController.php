<?php

namespace App\Http\Controllers;

use App\Models\RatingDetails;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RatingDetailsController extends Controller
{}