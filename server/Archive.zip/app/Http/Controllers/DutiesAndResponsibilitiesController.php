<?php

namespace App\Http\Controllers;

use App\Models\DutiesAndResponsibilities;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DutiesAndResponsibilitiesController extends Controller
{}