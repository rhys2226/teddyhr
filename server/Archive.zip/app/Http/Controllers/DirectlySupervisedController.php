<?php

namespace App\Http\Controllers;

use App\Models\DirectlySupervised;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DirectlySupervisedController extends Controller
{}