<?php

namespace App\Http\Controllers;

use App\Models\Notifications;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NotificationsController extends Controller
{
    
    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Notifications $notifications)
    {
        //
    }

    public function update(Request $request, Notifications $notifications)
    {
        //
    }

    public function destroy(Notifications $notifications)
    {
        //
    }
}
