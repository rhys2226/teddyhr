<?php

namespace App\Http\Controllers;

use App\Models\Compentencies;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CompentenciesController extends Controller
{}
